# BICapstone

URLS:
https://www.kaggle.com/c/digit-recognizer/data
