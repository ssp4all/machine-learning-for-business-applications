Author: Suraj Pawar

Student ID: 200315997

Unity ID: spawar2

Project: Attributed Graph Community Detection
