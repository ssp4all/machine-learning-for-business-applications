#! /usr/bin/python

# coding: utf-8

# ## A/B Paired Testing: Compare Means: Simulation

# In[2]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
get_ipython().magic('matplotlib inline')


# In[3]:


reading_scores_df = pd.read_csv('../data_raw/reading.txt', header=None, sep='\t')
reading_scores_df.columns=["Without Music", "With Music"]
print(reading_scores_df)
print(reading_scores_df.shape)


# In[4]:


def swap(x):
    if(np.random.random()>0.5):
        return [x[1],x[0]]
    else:
        return [x[0],x[1]]
    
def shuffle_data(data):
    shuffled_df =data.apply(swap, axis=1)
    mean_diff =(shuffled_df[shuffled_df.columns[1]].mean()-
     shuffled_df[shuffled_df.columns[0]].mean())
    return mean_diff
    
trials = []
n = 1000

for i in range(n):
    trials.append(shuffle_data(reading_scores_df))
trials_df = pd.DataFrame(trials, columns=['trial'])
pval =(trials_df['trial']>=1.45).sum()/float(n)
print("Paired comparison p-value: {0:.5f}".format(pval))


# In[5]:


trials_df.hist('trial')

