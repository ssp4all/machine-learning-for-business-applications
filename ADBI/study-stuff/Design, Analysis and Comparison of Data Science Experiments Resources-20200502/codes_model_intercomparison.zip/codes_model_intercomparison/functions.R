# function input:
# data - The data frame containing the target variable, the class output of the classifiers, and the fold ID.
# target - variable name (string) identifying the target variable
# output_classifier1 - variable name (string) identifying the class output of classifier 1
# output_classifier2 - variable name (string) identifying the class output of classifier 2
# fold_var - variable name (string) identifying the fold
paired_t_test_cv <- function(data, target, output_classifier1, output_classifier2, fold_var, significance_level = 0.05)
{
  fold_ids <- unique(data[, fold_var])
  model1_errors <- data[, target] != data[, output_classifier1]
  model2_errors <- data[, target] != data[, output_classifier2]
  # Calculate the error rate for each fold and for each model.
  model1_err_rate <- sapply(fold_ids, function(fold) sum(model1_errors[data[, fold_var] == fold]) /
                              sum(data[, fold_var] == fold))
  model2_err_rate <- sapply(fold_ids, function(fold) sum(model2_errors[data[, fold_var] == fold]) / 
                              sum(data[, fold_var] == fold))
  # Formula from Design and Analysis of Machine Learning Experiments, page 574
  m <- mean(model1_err_rate - model2_err_rate)
  S2 <- var(model1_err_rate - model2_err_rate) # In R, var gives a sample variance
  
  tstat <- sqrt(length(fold_ids)) * m / sqrt(S2)
  tstat_int <- qt(c( significance_level / 2, 1 - significance_level / 2 ), df = length(fold_ids) - 1 )
  print(paste("t-statistic", tstat, sep = "="))
  print(paste("Interval for", significance_level, "significance level:"))
  print(tstat_int)
  
  if (tstat_int[1] <= tstat && tstat <= tstat_int[2]) {
    # Inside interval - do not reject null hypothesis
    print("The two classifiers have a similar error rate.")
  } else {
    # Outside interval - reject null hypothesis
    print("The two classifiers do not have the same error rate at our significance level.")
  }
}





