
# Install the relevant libraries

if (!"reshape2" %in% rownames(installed.packages())) {
  install.packages("reshape2", dependencies = TRUE)
}
if (!"Rcpp" %in% rownames(installed.packages())) {
  install.packages("Rcpp", dependencies = TRUE)
}

if (!"stringi" %in% rownames(installed.packages())) {
  install.packages("stringi", dependencies = TRUE)
}

if (!"quantreg" %in% rownames(installed.packages())) {
  install.packages("quantreg", dependencies = TRUE)
}
if (!"colorspace" %in% rownames(installed.packages())) {
  install.packages("colorspace", dependencies = TRUE)
}
if (!"partykit" %in% rownames(installed.packages())) {
  install.packages("partykit", dependencies = TRUE)
}

if (!"cvTools" %in% rownames(installed.packages())) {
  install.packages("cvTools", dependencies = TRUE)
}
if (!"MASS" %in% rownames(installed.packages())) {
  install.packages("MASS", dependencies = TRUE)
}
if (!"rpart" %in% rownames(installed.packages())) {
  install.packages("rpart", dependencies = TRUE)
}
if (!"AER" %in% rownames(installed.packages())) {
  install.packages("AER", dependencies = TRUE)
}
if (!"caret" %in% rownames(installed.packages())) {
  install.packages("caret", dependencies = TRUE)
}
if (!"e1071" %in% rownames(installed.packages())) {
  install.packages("e1071", dependencies = TRUE)
}
if (!"multcomp" %in% rownames(installed.packages())) {
  install.packages("multcomp", dependencies = TRUE)
}
if (!"tree" %in% rownames(installed.packages())) {
  install.packages("tree", dependencies = TRUE)
}
if (!"randomForest" %in% rownames(installed.packages())) {
  install.packages("randomForest", dependencies = TRUE)
}
if (!"gplots" %in% rownames(installed.packages())) {
  install.packages("gplots", dependencies = TRUE)
}
if (!"epitools" %in% rownames(installed.packages())) {
  install.packages("epitools", dependencies = TRUE)
}
if (!"C50" %in% rownames(installed.packages())) {
  install.packages("C50", dependencies = TRUE)
}
if (!"glmnet" %in% rownames(installed.packages())) {
  install.packages("glmnet", dependencies = TRUE)
}
if (!"scmam" %in% rownames(installed.packages())) {
  install.packages("scmamp", dependencies = TRUE)
  source("https://bioconductor.org/biocLite.R") # Accept input from the URL
  biocLite("graph") #to install the dependency package no longer supported by CRAN
  biocLite("Rgraphviz") #to install the dependency package no longer supported by CRAN
}

# Load the relevant libraries
library(Rcpp)
library (stringi)
library(reshape2)
library(cvTools)
library(MASS)
library(rpart)
library(AER)
library(caret)
library(e1071)
library(multcomp)
library(tree)
library(randomForest)
library(gplots)
library(epitools)
library(C50)
library(glmnet)
library(scmamp)






