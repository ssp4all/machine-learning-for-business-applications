install.packages("fpp", dependencies=TRUE)
library(fpp)
data(package="fpp")

help.search("forecasting")
help(forecast)
example("forecast.ar")

# similar names
apropos("forecast")

help(package="fpp")

elecsales

data(dowjones)
